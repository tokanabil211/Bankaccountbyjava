public class BankAccount {
    private double Balance;
    public final static int ALLOWEDFEE = 6;

    protected  static int transactionCount;
    public BankAccount(){
        Balance=0;
    }
    public BankAccount(double balance){
        Balance=balance;
    }
    public void deposit(double amount){

        Balance=Balance+amount;


    }
    public void withdraw(double amount) {
        if (getBalance() < amount) {
            amount = Balance;
            System.out.println("Can only withdraw this amount :" + amount);
        } else {
            Balance = Balance - amount;
        }
    }
    public double getBalance(){
        return Balance;
    }
    public void transferMoney(BankAccount otherAccount , double amount){


        withdraw(amount);
        otherAccount.deposit(amount);



    }
    public void Display(){
        System.out.println("Balance ="+Balance);
    }


}
