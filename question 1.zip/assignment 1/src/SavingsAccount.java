public class SavingsAccount extends BankAccount{
     private double intersetRate;
    SavingsAccount(double rate){
        intersetRate=rate;

    }
    SavingsAccount(double rate, double balance){
        super(balance);
        intersetRate=rate;
    }
    public void addCompoundInterset()
    {

        double interset=getBalance()*intersetRate/100.0;
        deposit(interset);
    }


}
