public class CheckingAccount extends BankAccount {
    public final static int ALLOWED_TRANS = 2;
    public final static double TRANS_FEE = 3.0;


    public CheckingAccount() {
        super();
        transactionCount = 0;
    }

    public CheckingAccount(double balance) {
        super(balance);
        transactionCount = 0;
    }


    public void deposit(double amount) {
        if (transactionCount < ALLOWEDFEE) {
            super.deposit(amount);
            transactionCount++;


        } else {
            System.out.println("You CAN NOT MAKE MORE THAN 6 TRANSICTION .");
        }
    }

    public void withdraw(double amount) {
        if (transactionCount < ALLOWEDFEE) {
            super.withdraw(amount);
            transactionCount++;


        } else {
            System.out.println("You CAN NOT MAKE MORE THAN 6 TRANSICTION .");
        }
    }
    public void withdraww(double amount){
        super.withdraw(amount);
    }

    public void chargeFee() {
            if (transactionCount > 2) {

                double fee = (transactionCount-ALLOWED_TRANS)*TRANS_FEE;
                withdraww(fee);
            } else {
                transactionCount = 0;
            }


        }
    }

