import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        SavingsAccount dadsSavings=new SavingsAccount(0.3);
        CheckingAccount kidsChecking=new CheckingAccount();
        while (true) {
            System.out.println("-----------------------------------------------------------------------------------------------------");
            System.out.println("WELCOME OUR CLIENT !!!!!!! ");
            System.out.println("Choose from that menu : ");
            System.out.println("1-deposit");
            System.out.println("2-withdraw from kids balance");
            System.out.println("3-withdraw from dads balance");
            System.out.println("4-transfer money to other account ");
            System.out.println("5-end of program ");
            int number ;
            System.out.println("Enter the number :");
            number =sc.nextInt();
            if(number ==1)
            {
                double depositnumber ;
                System.out.println("What number should you want to deposit ? ");
                depositnumber=sc.nextDouble();

                dadsSavings.deposit(depositnumber);
                System.out.println("The balance after deposit :");
                dadsSavings.Display();

            }
            if (number ==4){
                System.out.println("Enter the amount to transfer :");
                double num;
                num= sc.nextDouble();
            dadsSavings.transferMoney(kidsChecking, num);
            }


            if(number==2){
                System.out.println("Enter the number to withdraw :");
                double x= sc.nextDouble();
                        kidsChecking.withdraw(x);

                        System.out.println("The balance after withdraw :");
                        kidsChecking.Display();
            }
            if(number==3){
                System.out.println("Enter the number to withdraw :");
                Double y= sc.nextDouble();
                dadsSavings.withdraw(y);
                System.out.println("The balance after withdraw :");
                dadsSavings.Display();
            }
            if(number==5){
                System.out.println("The End ");
                break;
            }
        }
System.out.println("******************************************************************************************************************");
System.out.println("THE BALANCE AFTER THE TRANSACTIONS :");
                dadsSavings.addCompoundInterset();
                kidsChecking.chargeFee();
            System.out.println("Dad saving account :");
            dadsSavings.Display();
            System.out.println("kid checking account :");
            kidsChecking.Display();
    }
}


